.. raw:: html

	<link rel="stylesheet" href="static/css/gist.css" type="text/css" />
	
==========
Change Log
==========

Recent additions to the SDK can be seen in the README on github:

https://raw.github.com/socialize/socialize-sdk-android/master/README